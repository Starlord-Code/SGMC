# SGMC

<img align="right" width="400" src="https://github-readme-stats.vercel.app/api?username=Starlord-Code&show_icons=true&theme=dracula&count_private=true" alt="Harsha's github stats" />

Smart  Grace Mark Allocator 

The project is Based on the improvement marks of the students accordingly to the grace marks they got from various events and publications of post, which is will be allocated grace mark allocator and the integration of the marks is done by the class adddivsor who will allocate more efficient way to distribution marks in the various subjects of a student so he can improve in his grades by the grace marks that he awared from various events that he participated.
