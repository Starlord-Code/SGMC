<?php 
session_start();
include('../config.php');
include('includes_CHF/header.php');

 

?>
<head>
<title>Dashboard</title> 
</head>
<?php
     $branch=$_SESSION['Branch'];
     $year=$_SESSION['Year'];
     $section=$_SESSION['Section'];
     $subject=$_SESSION['Subject'];

     
    ?>
          <!-- Banner -->
                <section class="main-banner">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="banner-content">
                                    <div class="row">
                                        <div class="col-md-12">
                                            <div class="banner-caption">
                                                <h4>Home Page of <em>Course Handling Faculty</em></h4>
                                                

                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>

                <section class="services1">
                    <div class="container-fluid">
                        <div class="row1">
                            <div class="col-md-12">
                                <div class="banner-content">
                                    <div class="row1">
                                        <div class="col-md-12">
                                            <div class="banner-caption">
                                               
                                                <span>Choose options from the  left panel to view or update marks.</span>
                                                <p>For any queries or suggestions contact <strong></strong>.</p>
                                                <div class="primary-button">
                                                    <a href="#">Read More</a>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>


            </div>
        </div>


<?php
    include('includes_CHF/navbar.php');
    include('includes_CHF/scripts.php');
    include('includes_CHF/footer.php');
   ?>